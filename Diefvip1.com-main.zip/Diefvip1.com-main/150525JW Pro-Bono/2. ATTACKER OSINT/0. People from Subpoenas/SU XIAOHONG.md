

----
![[Pasted image 20250514090017.png|350]]
![[Pasted image 20250514090052.png]]



![[26ABC485-9CE0-4660-91FB-C4E4C0222C8E.xlsx]]

#Phone_18206796009
#Email_1651649520

|                    |                                                                |                             |                     |                 |                   |                  |                    |                          |                          |        |         |                  |             |
| ------------------ | -------------------------------------------------------------- | --------------------------- | ------------------- | --------------- | ----------------- | ---------------- | ------------------ | ------------------------ | ------------------------ | ------ | ------- | ---------------- | ----------- |
| User ID            | Email                                                          | Mobile                      | Registration time   | First Name      | Last Name         | User nationality | User ID number     | User authentication type | User authentication time | Status | 2FA     | 2FA Opening time | SMS         |
| 802018410          | 1651649520[1651649520@qq.com](mailto:1651649520@qq.com)@qq.com | '+8618206796009             | 2023-11-04 10:19:39 | 苏晓红             |                   | CN               | 532322199208160048 | Personal                 | 2023-11-04 10:23:08      | Normal | Disable |                  | 18206796009 |
| API Information    |                                                                |                             |                     |                 |                   |                  |                    |                          |                          |        |         |                  |             |
| Rule ID            | API Name                                                       | Trade IP                    | Withdraw IP         | Create Time     | Update Time       |                  |                    |                          |                          |        |         |                  |             |
| KYC Approved Info  |                                                                |                             |                     |                 |                   |                  |                    |                          |                          |        |         |                  |             |
| Birthday           | ID issue Country                                               | ID Address                  | ID type             | ID Sub-type     | issuing Authority | Issuing Date     | ID expiry Date     |                          |                          |        |         |                  |             |
| 1992-08-16         | CN                                                             | 云南省楚雄彝族自治州双柏县妥甸镇和平村委会倒马坎村2号 | ID_CARD             |                 | 双柏县公安局            | 2019-06-05       | 2039-06-05         |                          |                          |        |         |                  |             |
| Address Validation |                                                                |                             |                     |                 |                   |                  |                    |                          |                          |        |         |                  |             |
| Residence          | Region/State                                                   | City                        | Address             | Postal/Zip Code |                   |                  |                    |                          |                          |        |         |                  |             |
| Sub-accounts       |                                                                |                             |                     |                 |                   |                  |                    |                          |                          |        |         |                  |             |
| Has Sub-account    | Sub-account Number                                             |                             |                     |                 |                   |                  |                    |                          |                          |        |         |                  |             |
| No                 | 0                                                              |                             |                     |                 |                   |                  |                    |                          |                          |        |         |                  |             |


Device History
#IP_112112206247
#IP_11211220627
#GMT_plus_8

|                     |                                      |                 |               |                              |        |           |                                          |
| ------------------- | ------------------------------------ | --------------- | ------------- | ---------------------------- | ------ | --------- | ---------------------------------------- |
| Device Name         | Client                               | IP Address      | Geolocation   | Recent Usage Timestamp (UTC) | Status | Key       | Value                                    |
| iPhone              | ios                                  | 112.112.206.247 | China Kunming | 2024-05-18 06:15:44          | Normal | fvideo_id | 13d047c60bfca492863ad980c4bced871f01c861 |
| app_install_date    | 2023-09-04 14:50:49                  |                 |               |                              |        |           |                                          |
| device_id           | 1716012943618pk271SDGX1taBPJ7Uc3     |                 |               |                              |        |           |                                          |
| system_lang         | zh-Hans-MV                           |                 |               |                              |        |           |                                          |
| timezone            | GMT+8                                |                 |               |                              |        |           |                                          |
| identification_type | Null                                 |                 |               |                              |        |           |                                          |
| cpu_memory_size     | 1574                                 |                 |               |                              |        |           |                                          |
| disk_size           | 238.28G                              |                 |               |                              |        |           |                                          |
| cpu_num             | 6                                    |                 |               |                              |        |           |                                          |
| screen_resolution   | (390.0, 844.0)                       |                 |               |                              |        |           |                                          |
| login_ip            | 112.112.206.247                      |                 |               |                              |        |           |                                          |
| operator            | '--                                  |                 |               |                              |        |           |                                          |
| device_uuid         | D1C6A7AC-EC32-41D8-A8D9-4B83B3247F42 |                 |               |                              |        |           |                                          |
| bnc-uuid            | f96247df50ca64f0e30d87990babd712     |                 |               |                              |        |           |                                          |
| device_name         | iPhone                               |                 |               |                              |        |           |                                          |
| system_version      | 17.4.1                               |                 |               |                              |        |           |                                          |
| cpu_type            | CPU_TYPE_ARM64                       |                 |               |                              |        |           |                                          |
| device_custom_name  | iPhone                               |                 |               |                              |        |           |                                          |
| brand_model         | iPhone 14                            |                 |               |                              |        |           |                                          |
| iPhone              | ios                                  | 112.112.206.27  | China Kunming | 2024-05-07 10:27:50          | Normal | fvideo_id | 13dfc9aa6933a497b8294276c5736cc4b1956e7b |
| app_install_date    | 2023-12-04 09:36:54                  |                 |               |                              |        |           |                                          |
| device_id           | 1715077669978daLO3daIdv9JNGxqJ8Z     |                 |               |                              |        |           |                                          |
| system_lang         | zh-Hans-GB                           |                 |               |                              |        |           |                                          |
| timezone            | GMT+8                                |                 |               |                              |        |           |                                          |
| identification_type | Null                                 |                 |               |                              |        |           |                                          |
| disk_size           | 119.09G                              |                 |               |                              |        |           |                                          |
| cpu_memory_size     | 3662                                 |                 |               |                              |        |           |                                          |
| cpu_num             | 6                                    |                 |               |                              |        |           |                                          |
| screen_resolution   | (390.0, 844.0)                       |                 |               |                              |        |           |                                          |
| login_ip            | 112.112.206.27                       |                 |               |                              |        |           |                                          |
| operator            | '--                                  |                 |               |                              |        |           |                                          |
| device_uuid         | 41C2563C-DFA3-4C1A-9091-3F34218923BA |                 |               |                              |        |           |                                          |
| bnc-uuid            | 3a0d07d5ad2c2d421352c34d1cefe56f     |                 |               |                              |        |           |                                          |
| device_name         | iPhone                               |                 |               |                              |        |           |                                          |
| cpu_type            | CPU_TYPE_ARM64                       |                 |               |                              |        |           |                                          |
| system_version      | 17.3.1                               |                 |               |                              |        |           |                                          |
| device_custom_name  | iPhone                               |                 |               |                              |        |           |                                          |
| brand_model         | iPhone 12                            |                 |               |                              |        |           |                                          |
| iPhone              | ios                                  | 39.130.125.6    | China Kunming | 2023-11-21 10:26:28          | Normal | fvideo_id | 13d12a43ad91a5ef8b9c89d5eba51bc7432bc4e7 |
| app_install_date    | 2023-06-30 06:54:15                  |                 |               |                              |        |           |                                          |
| device_id           | 1700562388020ZcXBYovmNER0Pkx0RBH     |                 |               |                              |        |           |                                          |
| system_lang         | zh-Hans-CN                           |                 |               |                              |        |           |                                          |
| timezone            | GMT+8                                |                 |               |                              |        |           |                                          |
| identification_type | Null                                 |                 |               |                              |        |           |                                          |
| disk_size           | 119.09G                              |                 |               |                              |        |           |                                          |
| cpu_memory_size     | 3670                                 |                 |               |                              |        |           |                                          |
| cpu_num             | 6                                    |                 |               |                              |        |           |                                          |
| screen_resolution   | (390.0, 844.0)                       |                 |               |                              |        |           |                                          |
| login_ip            | 39.130.125.6                         |                 |               |                              |        |           |                                          |
| device_uuid         | 19601816-EAD4-462A-AFFA-708D7796732E |                 |               |                              |        |           |                                          |
| operator            | '--                                  |                 |               |                              |        |           |                                          |
| bnc-uuid            | 383d968335e2029488aadb15a992369e     |                 |               |                              |        |           |                                          |
| device_name         | iPhone                               |                 |               |                              |        |           |                                          |
| cpu_type            | CPU_TYPE_ARM64                       |                 |               |                              |        |           |                                          |
| system_version      | 16.6                                 |                 |               |                              |        |           |                                          |
| device_custom_name  | iPhone                               |                 |               |                              |        |           |                                          |
| brand_model         | iPhone 12                            |                 |               |                              |        |           |                                          |